Paket içeriği (test publish for v1.0.0.3):

- release_message.txt   --> Bu metin dosyasını güncelleme paketi içinde koyduk.

Kullanım:
1. publish/v1.0.0.3 klasörünü zip'leyin (ör. TurizmOperasyonSistemi-publish-1.0.0.3.zip).
2. GitHub Release oluşturup bu zip'i "Assets" olarak yükleyin.
3. latest.json dosyasını (aşağıdaki örnek) GitHub Release veya barındırdığınız manifest URL'sine koyun.
4. Uygulama çalıştırıldığında UpdateBackgroundService manifest'i okuyacak ve paket bulunduğunda indirip Updater.exe ile kuracaktır.

Not: Bu test paketi sadece bir metin dosyası içerir; gerçek uygulama/dll/xaml değişiklikleri için publish çıktınızı zip'leyip yükleyin.
